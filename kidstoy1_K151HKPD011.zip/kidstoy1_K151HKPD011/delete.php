
Delete.php
<?php
include 'config.php'; 
	if (isset($_GET["kod_produk"])){// sending query
	mysqli_query($connection, "DELETE FROM jadual_item WHERE kod_produk ='$_GET[$kod_produk]'")or die ( mysqli_error()) ;
		
	echo("Location: index.php");
?>
